Anti QQkey

Update 1.5:
添加内存校验

by Krgjd
511413324